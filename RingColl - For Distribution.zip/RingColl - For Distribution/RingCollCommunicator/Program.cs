﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using RingAriaQ;
using System.Management;

namespace RingCollCommunicator
{
    class Program
    {
        private static IDeviceComm _comm;

        static void Main(string[] args)
        {
            //------------------------------
            // Find Port (retry until found)
            //------------------------------
            string port = null;

            Console.WriteLine("Waiting for Arduino to connect...");

            while (port == null)
            {
                port = FindArduinoPort();

                if (port == null)
                {
                    Console.WriteLine($"  [{DateTime.Now:HH:mm:ss}] Arduino not detected. Retrying in 3s...");
                    Thread.Sleep(3000);
                }
            }

            Console.WriteLine($"Auto-detected Arduino on {port}");

            //------------------------------
            // Connect to Com (retry if port not ready)
            //------------------------------
            IDeviceComm comm = null;

            while (comm == null)
            {
                try
                {
                    comm = new SerialComm(port);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"  Port found but connection failed: {ex.Message}");
                    Console.WriteLine("  Retrying in 3s...");
                    Thread.Sleep(3000);

                    // Re-check port in case it changed
                    port = FindArduinoPort() ?? port;
                }
            }

            _comm = comm;
            _comm.MessageReceived += OnMessageReceived;
            _comm.Start();

            Console.WriteLine("Listener running...");
            Thread.Sleep(Timeout.Infinite);
        }

        private static void OnMessageReceived(string message)
        {
            Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Arduino Says: {message}");

            if (message == "ReadyForSegments")
            {
                try
                {
                    var mrn = GetCurrentPatientMRN();
                    if (string.IsNullOrEmpty(mrn))
                    {
                        return;
                    }

                    var collision = CollisionFileReader.GetLatest(mrn);
                    if (collision?.Sectors?.Any() == true)
                    {
                        var payload = string.Join(",", collision.Sectors);
                        Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Communicator: MRN: {mrn} | Sectors: {payload}");
                        _comm.Send(payload);
                    }
                    else
                    {
                        Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Communicator: MRN: {mrn} | No collisions.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Communicator: ERROR: {ex.Message}");
                }
            }
        }

        public static class CollisionFileReader
        {
            private static readonly string FolderPath = @"*******************************";

            public static CollisionData GetLatest(string mrn)
            {
                var filePath = Path.Combine(FolderPath, $"{mrn}.json");

                if (!File.Exists(filePath))
                    return null;

                var json = File.ReadAllText(filePath);
                var records = JsonConvert.DeserializeObject<List<CollisionData>>(json);

                if (records.Count > 1)
                {
                    Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Communicator: Multiple Plans found for this patient... currently we only support single plans");
                    return null;
                }
                
                return records?.OrderByDescending(r => r.Timestamp).FirstOrDefault();
            }
        }

        public class CollisionData
        {
            public string Course { get; set; }
            public string Plan { get; set; }
            public List<int> Sectors { get; set; }
            public DateTime Timestamp { get; set; }
        }


        private static string GetCurrentPatientMRN()
        {
            Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Communicator: Getting current In-Progress patient from ARIA");

            Stopwatch stopwatch = Stopwatch.StartNew();

            DateTime dateStart = DateTime.Now.Date;
            DateTime dateEnd = dateStart.AddDays(1);
            List<string> includeNewStartAppointments = new List<string> { "TREATMENT" , "PATIENT QA"};
            string machineId = "********";
            string inProgressPt = null;
            using (var aria = new RingAria())
            {
                inProgressPt = aria.ScheduledActivities
                    .Where(sa => sa.ScheduledStartTime >= dateStart
                              && sa.ScheduledStartTime < dateEnd
                              && sa.ScheduledActivityCode != "Cancelled"
                              && sa.ActivityInstance.ObjectStatus != "Deleted"
                              && sa.ScheduledActivityCode == "In Progress"
                              && includeNewStartAppointments.Any(x =>
                                    sa.ActivityInstance.Activity.ActivityCode.ToUpper().Contains(x.ToUpper()))
                              && sa.ActivityInstance.Attendees.Any(att =>
                                    att.Resource.ResourceType.Contains("Machine")
                                    && att.ObjectStatus == "Active"
                                    && att.Resource.Machine.MachineId == machineId))
                    .Select(sa => sa.Patient.PatientId)
                    .FirstOrDefault();

                if (!String.IsNullOrEmpty(inProgressLA2Pt))
                {
                    Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Communicator: In Progress found: {inProgressPt}");
                }
                else
                {
                    Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Communicator: No In Progress patient found.");
                }
            }
            stopwatch.Stop();
            Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Communicator: EllapsedTime {stopwatch.ElapsedMilliseconds / 1000.0}s");

            return inProgressPt;
        }

        // -------Interface ---------------──────────────────────────────────────────────
        public interface IDeviceComm
        {
            event Action<string> MessageReceived;
            void Send(string message);
            void Start();
            void Stop();
        }
        public class SerialComm : IDeviceComm
        {
            private SerialPort _port;
            public event Action<string> MessageReceived;

            public SerialComm(string portName, int baud = 9600)
            {
                _port = new SerialPort(portName, baud);
                _port.DataReceived += (s, e) =>
                {
                    var line = _port.ReadLine().Trim();
                    MessageReceived?.Invoke(line);
                };
            }

            public void Send(string message) => _port.WriteLine(message);

            public void Start() => _port.Open();

            public void Stop()
            {
                _port.Close();
                _port.Dispose();
            }
        }

        public static string FindArduinoPort()
        {
            using (var searcher = new ManagementObjectSearcher(
                "SELECT * FROM Win32_PnPEntity WHERE Caption LIKE '%Arduino%'"))
            {
                foreach (var device in searcher.Get())
                {
                    string caption = device["Caption"]?.ToString() ?? "";
                    // Caption looks like: "Arduino MKR WiFi 1010 (COM8)"
                    var match = System.Text.RegularExpressions.Regex.Match(caption, @"\(COM(\d+)\)");
                    if (match.Success)
                        return $"COM{match.Groups[1].Value}";
                }
            }
            return null;
        }

    }
}
