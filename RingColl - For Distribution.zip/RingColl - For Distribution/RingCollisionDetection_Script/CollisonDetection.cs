using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media.Media3D;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;

/// <summary>
/// Improved Gantry Collision Detection
/// =====================================
/// Geometry reference:
///   - General collision cylinder radius : 380 mm from isocenter (XY plane)
///   - Axial evaluation window           : ±400 mm from iso in Z
///   - Laser ring segments               : 8 segments of 37.5° each (Segment1–Segment8)
///     Segment1 starts at 0° (12 o'clock / top of ring)
///     Angle increases clockwise viewed from foot of patient
///     Exclusion zone (no lasers)        : 150°–210° (electronic box location)
/// </summary>
public static class GantryCollisionCheck
{
    // -----------------------------------------------------------------------
    // Constants
    // -----------------------------------------------------------------------
    public const double GeoCollisionThreshold = 380.0;  // mm
    public const double AxialHalfExtent       = 400.0;  // mm  (±400 from iso)
    public const double RadialTruncation      = 400.0;  // mm  (80 cm diameter = 400 mm radius)
    public const int    NumRingSectors        = 8;
    public const double SectorDegrees         = 37.5;  // 360° / 8 segments
    public const double ExclusionZoneLow      = 150.0; // exclusion starts (°)
    public const double ExclusionZoneHigh     = 210.0; // exclusion ends (°)

    // -----------------------------------------------------------------------
    // Result types
    // -----------------------------------------------------------------------
    public class StructureResult
    {
        public string  StructureId            { get; set; }
        public bool    Passed                 { get; set; }
        public double  MaxRadialDistAll       { get; set; }   // ignoring Z clamp
        public double  MaxRadialDistClamped   { get; set; }   // within Z window AND radial
        public int     PointsOutsideZWindow   { get; set; }
        public int     PointsOutsideRadial    { get; set; }   // outside 80cm diameter
        public int     TotalPoints            { get; set; }

        // Populated only when Passed == false
        public double? ViolationAngleDeg      { get; set; }
        public string  ViolationRingSector    { get; set; }
        public VVector ViolationPoint         { get; set; }

        // Per-segment collision status: Dictionary[SegmentName] = hasCollision
        public Dictionary<string, bool> SegmentCollisions { get; set; } = new Dictionary<string, bool>();

        public List<string> Warnings          { get; set; } = new List<string>();
    }

    public class CheckSummary
    {
        public bool                  OverallPass { get; set; }
        public List<StructureResult> Results     { get; set; } = new List<StructureResult>();
        public List<string>          Messages    { get; set; } = new List<string>();
    }

    // -----------------------------------------------------------------------
    // Public entry point — drop-in replacement for the original foreach block
    // -----------------------------------------------------------------------

    /// <summary>
    /// Run the improved geometry collision check.
    /// </summary>
    /// <param name="ssList">Structures to check (e.g. BODY, couch parts).</param>
    /// <param name="iso">Isocenter coordinates (mm).</param>
    /// <param name="geoCollisionThreshold">Max allowed radial distance (mm). Default 380.</param>
    /// <param name="axialHalfExtent">Half-extent of Z evaluation window (mm). Default 400.</param>
    /// <returns>CheckSummary with per-structure results and overall pass/fail.</returns>
    public static CheckSummary RunCheck(
        IEnumerable<Structure> ssList,
        VVector iso,
        string treatOrientation,
        double geoCollisionThreshold = GeoCollisionThreshold,
        double axialHalfExtent       = AxialHalfExtent)
    {
        var summary = new CheckSummary { OverallPass = true };

        foreach (var s in ssList)
        {
            var result = CheckStructure(s, iso, geoCollisionThreshold, axialHalfExtent, treatOrientation);
            summary.Results.Add(result);

            foreach (var w in result.Warnings)
                summary.Messages.Add($"WARNING [{s.Id}]: {w}");

            if (!result.Passed)
            {
                summary.OverallPass = false;
                summary.Messages.Add(
                    $"COLLISION: '{s.Id}' — max radial dist {result.MaxRadialDistClamped:F1} mm " +
                    $"(threshold {geoCollisionThreshold} mm) at gantry angle " +
                    $"{result.ViolationAngleDeg:F1}° → {result.ViolationRingSector}");
            }
        }

        return summary;
    }

    // -----------------------------------------------------------------------
    // Per-structure check
    // -----------------------------------------------------------------------
    private static StructureResult CheckStructure(
        Structure s,
        VVector   iso,
        double    threshold,
        double    axialHalf,
        string treatOrientation)
    {
        var result = new StructureResult
        {
            StructureId  = s.Id,
            Passed       = true,
            TotalPoints  = s.MeshGeometry.Positions.Count,
        };

        double zLo = iso.z - axialHalf;
        double zHi = iso.z + axialHalf;

        // Initialize per-segment collision dictionary
        for (int i = 1; i <= NumRingSectors; i++)
            result.SegmentCollisions[$"Segment{i}"] = false;

        // Split positions into inside/outside the axial window AND radial truncation
        var inWindow  = new List<Point3D>();
        int outsideZ  = 0;
        int outsideRadial = 0;

        foreach (var p in s.MeshGeometry.Positions)
        {
            if (p.Z < zLo || p.Z > zHi)
            {
                outsideZ++;
                continue;
            }

            double radialDist = RadialDistXY(p, iso);
            if (radialDist > RadialTruncation)
                outsideRadial++;   // count for information only — point is still evaluated

            inWindow.Add(p);
        }

        result.PointsOutsideZWindow = outsideZ;
        result.PointsOutsideRadial = outsideRadial;

        // Warn if anatomy extends beyond the axial window
        if (outsideZ > 0)
        {
            double fraction = (double)outsideZ / result.TotalPoints * 100.0;
            result.Warnings.Add(
                $"{outsideZ} / {result.TotalPoints} points ({fraction:F0}%) lie outside " +
                $"the ±{axialHalf:F0} mm axial window and were NOT evaluated — " +
                $"anatomy there is unscreened.");
        }

        // Warn if anatomy extends beyond the physical bore clearance — these points ARE evaluated
        if (outsideRadial > 0)
        {
            double fraction = (double)outsideRadial / result.TotalPoints * 100.0;
            result.Warnings.Add(
                $"{outsideRadial} / {result.TotalPoints} points ({fraction:F0}%) lie beyond " +
                $"the {RadialTruncation:F0} mm physical bore clearance — " +
                $"definite collision zone, included in evaluation.");
        }

        // Unclamped max radius (kept for reference / legacy comparison)
        result.MaxRadialDistAll = s.MeshGeometry.Positions
            .Select(p => RadialDistXY(p, iso))
            .DefaultIfEmpty(0)
            .Max();

        if (inWindow.Count == 0)
        {
            result.Warnings.Add(
                $"No points inside the axial window — no collision evaluated.");
            return result;
        }

        // Find the worst point inside the axial window
        Point3D worstPoint   = inWindow[0];
        double  maxRClamped  = 0;

        foreach (var p in inWindow)
        {
            double r = RadialDistXY(p, iso);
            if (r > maxRClamped)
            {
                maxRClamped = r;
                worstPoint  = p;
            }
        }

        result.MaxRadialDistClamped = maxRClamped;

        // Find all collision points and mark affected segments
        var collisionPointsBySegment = new Dictionary<string, List<Point3D>>();

        foreach (var p in inWindow)
        {
            double r = RadialDistXY(p, iso);
            if (r > threshold)
            {
                double angleDeg = AngleFromIsoDeg(p, iso);
                string segment = AngleToRingSector(angleDeg, treatOrientation);

                if (!collisionPointsBySegment.ContainsKey(segment))
                    collisionPointsBySegment[segment] = new List<Point3D>();

                collisionPointsBySegment[segment].Add(p);

                // Mark segment as having collision (unless it's the exclusion zone)
                if (segment != "NONE (exclusion zone 150–210°)")
                    result.SegmentCollisions[segment] = true;
            }
        }

        // If any collisions found, flag as failed and record the worst one
        if (collisionPointsBySegment.Count > 0)
        {
            result.Passed = false;
            // Record the worst point (highest radial distance)
            Point3D worstCollisionPoint = collisionPointsBySegment.Values
                .SelectMany(pts => pts)
                .OrderByDescending(p => RadialDistXY(p, iso))
                .First();

            result.ViolationAngleDeg   = AngleFromIsoDeg(worstCollisionPoint, iso);
            result.ViolationRingSector = AngleToRingSector(result.ViolationAngleDeg.Value, treatOrientation);
            result.ViolationPoint      = new VVector(worstCollisionPoint.X, worstCollisionPoint.Y, worstCollisionPoint.Z);
        }

        return result;
    }

    // -----------------------------------------------------------------------
    // Geometry helpers
    // -----------------------------------------------------------------------

    /// <summary>
    /// Transforms the patient-coordinate angle into a room-coordinate angle
    /// so the ring sector mapping is consistent regardless of orientation.
    /// </summary>
    private static double NormalizeAngleToRoom(double patientAngleDeg, string treatOrientation)
    {
        string orientation = treatOrientation.ToUpper();

        bool feetFirst = orientation.Contains("FEET");
        bool prone = orientation.Contains("PRONE");

        double roomAngle = patientAngleDeg;

        if (feetFirst && !prone)
        {
            // FFS: X flips → mirror about the Y axis
            roomAngle = (360.0 - patientAngleDeg) % 360.0;
        }
        else if (!feetFirst && prone)
        {
            // HFP: X flips AND Y flips → rotate 180°
            roomAngle = (patientAngleDeg + 180.0) % 360.0;
        }
        else if (feetFirst && prone)
        {
            // FFP: Y flips → mirror about the X axis
            roomAngle = (180.0 - patientAngleDeg + 360.0) % 360.0;
        }
        // else HFS: no transform needed

        return roomAngle;
    }



    /// <summary>
    /// Radial distance from point to iso projected onto the XY plane (ignores Z).
    /// </summary>
    private static double RadialDistXY(Point3D p, VVector iso)
    {
        double dx = p.X - iso.x;
        double dy = p.Y - iso.y;
        return Math.Sqrt(dx * dx + dy * dy);
    }

    /// <summary>
    /// Gantry angle (0–360°) at which the gantry head would point toward this point.
    /// Convention: 0° = beam from superior (Y+, 12 o'clock).
    /// Increases clockwise when viewed from the foot of the patient.
    /// </summary>
    private static double AngleFromIsoDeg(Point3D p, VVector iso)
    {
        double dx = p.X - iso.x;
        double dy = p.Y - iso.y;
        // Math.Atan2(dx, dy) gives clockwise angle from +Y directly
        double angleDeg = Math.Atan2(dx, dy) * (180.0 / Math.PI);
        return ((angleDeg % 360.0) + 360.0) % 360.0;   // normalise to 0–360
    }

    /// <summary>
    /// Check if angle falls within exclusion zone (150°–210°).
    /// </summary>
    private static bool IsInExclusionZone(double angleDeg)
    {
        return angleDeg >= ExclusionZoneLow && angleDeg <= ExclusionZoneHigh;
    }

    ///Translation Dictionary
    ///Have to translate Amrbose's code to sequential pin relay in Ardiuno
    private static int TranslateSegmentNumbers(int ambroseSegment)
    {
        return 9 - ambroseSegment;
    }

    /// <summary>
    /// Map a gantry angle (0–360°) to a laser segment name (Segment1–Segment8).
    /// Segment1 = 0–37.5°, Segment2 = 37.5–75°, …, Segment8 = 322.5–360°
    /// Exclusion zone 150–210° has no lasers and returns "NONE".
    /// </summary>
    private static string AngleToRingSector(double angleDeg, string treatOrientation)
    {

        // Transform patient angle to room angle FIRST
        double roomAngle = NormalizeAngleToRoom(angleDeg, treatOrientation);

        if (IsInExclusionZone(roomAngle))
            return "NONE (exclusion zone 150–210°)";

        int amrboseSegment = 0;
        if (roomAngle < ExclusionZoneLow)
        {
            amrboseSegment = (int)(roomAngle / SectorDegrees) + 1;
            
        }
        else
        {
            amrboseSegment = (int)((roomAngle - ExclusionZoneHigh) / SectorDegrees) + 5;
        }

        //Translate Ambrose's segment numbering to match the physical ring layout (Segment1 at 0°)
        var ringSegment = TranslateSegmentNumbers(amrboseSegment);
        return $"Segment{ringSegment}";
    }

    // -----------------------------------------------------------------------
    // Optional: pretty-print to Console (useful during development)
    // -----------------------------------------------------------------------
    /// <summary>
    /// Print per-segment collision status (YES/NO for each segment).
    /// </summary>
    public static void PrintSegmentStatus(CheckSummary summary)
    {
        string bar = new string('=', 60);
        Console.WriteLine(bar);
        Console.WriteLine("  LASER RING SEGMENT COLLISION STATUS");
        Console.WriteLine(bar);

        // Aggregate all segments from all structures
        var allSegments = new Dictionary<string, bool>();
        for (int i = 1; i <= NumRingSectors; i++)
            allSegments[$"Segment{i}"] = false;

        foreach (var result in summary.Results)
        {
            foreach (var kvp in result.SegmentCollisions)
            {
                if (kvp.Value)
                    allSegments[kvp.Key] = true;
            }
        }

        // Print each segment
        foreach (var kvp in allSegments.OrderBy(x => int.Parse(x.Key.Replace("Segment", ""))))
        {
            string status = kvp.Value ? "YES" : "NO ";
            Console.WriteLine($"  {kvp.Key:10} : {status}");
        }

        Console.WriteLine(bar);
    }

    public static void PrintSummary(CheckSummary summary, VVector iso)
    {
        string bar = new string('=', 60);
        Console.WriteLine(bar);
        Console.WriteLine("  GANTRY COLLISION CHECK SUMMARY");
        Console.WriteLine(bar);
        Console.WriteLine($"  Isocenter : ({iso.x:F2}, {iso.y:F2}, {iso.z:F2}) mm");
        Console.WriteLine($"  Overall   : {(summary.OverallPass ? "PASS — No collision predicted" : "FAIL — Collision(s) predicted")}");
        Console.WriteLine();

        foreach (var r in summary.Results)
        {
            string status = r.Passed ? "PASS" : "FAIL";
            Console.WriteLine($"  [{status}] {r.StructureId}");
            Console.WriteLine($"         max radial (all Z)      : {r.MaxRadialDistAll:F1} mm");
            Console.WriteLine($"         max radial (±400 Z)     : {r.MaxRadialDistClamped:F1} mm");
            Console.WriteLine($"         points outside Z        : {r.PointsOutsideZWindow} / {r.TotalPoints}");
            Console.WriteLine($"         points outside radial   : {r.PointsOutsideRadial} / {r.TotalPoints}");
            if (!r.Passed)
            {
                Console.WriteLine($"         collision angle         : {r.ViolationAngleDeg:F1}°");
                Console.WriteLine($"         affected ring segment   : {r.ViolationRingSector}");
                var p = r.ViolationPoint;
                Console.WriteLine($"         worst point             : ({p.x:F1}, {p.y:F1}, {p.z:F1}) mm");
            }
            foreach (var w in r.Warnings)
                Console.WriteLine($"         WARNING: {w}");
            Console.WriteLine();
        }

        // Print segment status
        PrintSegmentStatus(summary);

        if (summary.Messages.Count > 0)
        {
            Console.WriteLine(bar);
            Console.WriteLine("  MESSAGES");
            Console.WriteLine(bar);
            foreach (var m in summary.Messages)
                Console.WriteLine($"  • {m}");
        }
        Console.WriteLine(bar);
        Console.WriteLine();
        Console.WriteLine($"COLLISION PREDICTED: {(summary.OverallPass ? "NO" : "YES")}");
    }
}

// -----------------------------------------------------------------------
// Example: how to call it from your existing script
// -----------------------------------------------------------------------
//
//   var ssList = new List<Structure> { body, couchSurface, couchInterior, ... };
//   var iso    = plan.Beams.First().IsocenterPosition;
//
//   var summary = GantryCollisionCheck.RunCheck(ssList, iso);
//
//   // Simple yes/no (matches your original output pattern)
//   bool passedGEO = summary.OverallPass;
//   var  messages  = summary.Messages;
//
//   // Optional: print full report to console
//   GantryCollisionCheck.PrintSummary(summary, iso);
//