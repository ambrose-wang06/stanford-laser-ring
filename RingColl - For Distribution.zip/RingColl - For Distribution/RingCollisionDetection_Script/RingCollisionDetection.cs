using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Xml;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;

// TODO: Replace the following version attributes by creating AssemblyInfo.cs. You can do this in the properties of the Visual Studio project.
[assembly: AssemblyVersion("1.0.0.1")]
[assembly: AssemblyFileVersion("1.0.0.1")]
[assembly: AssemblyInformationalVersion("1.0")]

namespace VMS.TPS
{
    public class CollisionData
    {
        public string MRN { get; set; }
        public string Course { get; set; }
        public string Plan { get; set; }
        public List<int> Sectors { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class Script
    {
        public Script()
        {
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        public void Execute(ScriptContext context /*, System.Windows.Window window, ScriptEnvironment environment*/)
        {
            var patient = context.Patient;
            var course = context.Course;
            var plan = context.PlanSetup;

            if (plan != null)
            {

                var structuresToEval = plan.StructureSet.Structures
                    .Where(s =>
                        s.Id.ToUpper().Contains("BODY")
                        || s.DicomType == "EXTERNAL"
                        || s.DicomType == "SUPPORT")
                    .ToList();
                structuresToEval.RemoveAll(s => s.IsEmpty);

                var iso = plan.Beams.First().IsocenterPosition;
                var treatOrientation = plan.TreatmentOrientationAsString;

                var stoptwatch = System.Diagnostics.Stopwatch.StartNew();
                var summary = GantryCollisionCheck.RunCheck(structuresToEval, iso, treatOrientation);
                stoptwatch.Stop();

                double timeInSec = stoptwatch.ElapsedMilliseconds / 1000.0;

                var collDetected = summary.OverallPass;

                Console.WriteLine($"Elappsed Time: {timeInSec:0.00}s");

                var segmentCollisions = summary.Results
                    .Where(r => !r.Passed)
                    .SelectMany(r => r.SegmentCollisions
                        .Where(s => s.Value == true)
                        .Select(s => new
                        {
                            Structure = r.StructureId,
                            Segment = s.Key.Replace("Segment", "")
                        }))
                    .Where(x => int.TryParse(x.Segment, out _))
                    .GroupBy(x => int.Parse(x.Segment))
                    .Select(g => new
                    {
                        Segment = g.Key,
                        Structures = g.Select(x => x.Structure).Distinct().ToList()
                    })
                    .OrderBy(x => x.Segment)
                    .ToList();

                var displayString = string.Join(", ", segmentCollisions.Select(x => $"{x.Segment} ({string.Join(", ", x.Structures)})"));
                var segmentNumbers = segmentCollisions.Select(x => x.Segment).ToList();

                //var segments = summary.Results
                //    .Where(r => !r.Passed)
                //    .SelectMany(r => r.SegmentCollisions.Where(s => s.Value == true))
                //    .Select(s => s.Key)
                //    .Distinct()
                //    .Select(x => x.Replace("Segment", ""))
                //    .Select(x => int.TryParse(x, out int segNum) ? segNum : 0)
                //    .ToList();

                string message = "";

                if (segmentNumbers.Count == 0)
                {
                    message += "No collisions detected. ";
                    segmentNumbers = new List<int> { };
                }
                else
                {
                    Console.WriteLine($"SEGMENTS DETECTED: {String.Join(", ", segmentNumbers)}");
                    message += $"Collisions detected in segments: {displayString}";
                }

                // Check if file exists and prompt user
                var writeResult = CollisionFileWriter.WriteCollisionWithPrompt(patient.Id, course.Id, plan.Id, segmentNumbers);

                if (writeResult == CollisionWriteResult.Cancelled)
                {
                    message += "\n\nSave cancelled by user.";
                }
                else if (writeResult == CollisionWriteResult.Added)
                {
                    message += $"\nCollision data ADDED to {patient.Id}.json";
                }
                else if (writeResult == CollisionWriteResult.Overridden)
                {
                    message += $"\nCollision data OVERRODE previous plans in {patient.Id}.json";
                }
                else if (writeResult == CollisionWriteResult.SavedNew)
                {
                    message += $"\nCollision data saved to {patient.Id}.json";
                }

                message += $"\n\n--- Elapsed Time: {timeInSec:0.00}s ---";
                MessageBox.Show(message, "Collision Detection Result", MessageBoxButton.OK, MessageBoxImage.Information);


            }
            else
            {
                throw new InvalidOperationException("No plan is currently open. Please open a plan and try again.");
            }

        }
    }

    public enum CollisionWriteResult
    {
        SavedNew,
        Added,
        Overridden,
        Cancelled
    }


    public static class CollisionFileWriter
    {
        private static readonly string FolderPath =
            @"******************************************";

        public static CollisionWriteResult WriteCollisionWithPrompt(
            string mrn, string course, string plan, List<int> sectors)
        {
            Directory.CreateDirectory(FolderPath);

            var filePath = Path.Combine(FolderPath, $"{mrn}.json");
            var existingRecords = LoadFile(filePath);

            // If file has existing records, prompt the user
            if (existingRecords.Count > 0)
            {
                // Build a summary of what's already saved
                string existingSummary = string.Join("\n",
                    existingRecords.Select(r => $"  {r.Course} / {r.Plan} - dSectors: [{string.Join(",", r.Sectors)}]"));

                string promptMessage =
                    $"Collision data already exists for MRN {mrn}:\n\n" +
                    $"{existingSummary}\n\n" +
                    $"New data: {course} / {plan} � Sectors: [{string.Join(",", sectors)}]\n\n" +
                    "YES = Add to existing plans\n" +
                    "NO = Override (replace ALL with this plan only)\n" +
                    "CANCEL = Exit without saving";

                var result = MessageBox.Show(
                    promptMessage,
                    "Collision Data Already Exists",
                    MessageBoxButton.YesNoCancel,
                    MessageBoxImage.Question);

                switch (result)
                {
                    case MessageBoxResult.Yes:
                        // ADD: keep existing, add/update this plan
                        AddOrUpdate(existingRecords, mrn, course, plan, sectors);
                        SaveFile(filePath, existingRecords);
                        return CollisionWriteResult.Added;

                    case MessageBoxResult.No:
                        // OVERRIDE: wipe everything, save only this plan
                        var freshList = new List<CollisionData>
                    {
                        new CollisionData
                        {
                            MRN = mrn,
                            Course = course,
                            Plan = plan,
                            Sectors = sectors,
                            Timestamp = DateTime.Now
                        }
                    };
                        SaveFile(filePath, freshList);
                        return CollisionWriteResult.Overridden;

                    case MessageBoxResult.Cancel:
                    default:
                        return CollisionWriteResult.Cancelled;
                }
            }
            else
            {
                // No existing data � just save directly
                var records = new List<CollisionData>
            {
                new CollisionData
                {
                    MRN = mrn,
                    Course = course,
                    Plan = plan,
                    Sectors = sectors,
                    Timestamp = DateTime.Now
                }
            };
                SaveFile(filePath, records);
                return CollisionWriteResult.SavedNew;
            }
        }

        private static void AddOrUpdate(
            List<CollisionData> records, string mrn, string course, string plan, List<int> sectors)
        {
            var existing = records.FirstOrDefault(r => r.Course == course && r.Plan == plan);

            if (existing != null)
            {
                existing.Sectors = sectors;
                existing.Timestamp = DateTime.Now;
            }
            else
            {
                records.Add(new CollisionData
                {
                    MRN = mrn,
                    Course = course,
                    Plan = plan,
                    Sectors = sectors,
                    Timestamp = DateTime.Now
                });
            }
        }

        private static void SaveFile(string filePath, List<CollisionData> records)
        {
            var json = JsonConvert.SerializeObject(records, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        private static List<CollisionData> LoadFile(string filePath)
        {
            if (!File.Exists(filePath))
                return new List<CollisionData>();

            var json = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<List<CollisionData>>(json)
                   ?? new List<CollisionData>();
        }
    }
}



