#include <IRremote.hpp>

#define IR_RECEIVE_PIN 14

const int relayPins[] = {5, 4, 3, 2, 1, 0, A6, A5}; //Maps onto 
const int relayCount = 8;

bool laserState = false;
bool blinkingRelays[relayCount] = {false};
bool waitingForSegments = false;

unsigned long lastBlinkTime = 0;
const unsigned long blinkInterval = 175;

unsigned long lastValidSignalTime = 0;
unsigned long debounceDelay = 500;

void setup() {
    Serial.begin(9600);
    Serial.println("Starting Laser Control System...");

    IrReceiver.begin(IR_RECEIVE_PIN, ENABLE_LED_FEEDBACK);

    for (int i = 0; i < relayCount; i++) {
        pinMode(relayPins[i], OUTPUT);
        digitalWrite(relayPins[i], LOW);
        Serial.print("Relay ");
        Serial.print(i + 1);
        Serial.println(" initialized to OFF.");
    }

    Serial.println("System ready. Waiting for IR signal.");
}

void loop() {
    handleIRSignals();
    handleSerialResponse();
    handleBlinking();
}

// ─── IR HANDLING ─────────────────────────────────────────────

void handleIRSignals() {
    if (IrReceiver.decode()) {
        unsigned long currentMillis = millis();

        if (IrReceiver.decodedIRData.decodedRawData == 0xF1D2D) {
            if (currentMillis - lastValidSignalTime > debounceDelay) {

                if (laserState) {
                    shutdownLasers();
                } else {
                    activateLasers();
                }

                lastValidSignalTime = currentMillis;
            } else {
                Serial.println("Ignored repeated signal due to debounce.");
            }
        }

        IrReceiver.resume();
    }
}

// ─── ACTIVATE / SHUTDOWN ─────────────────────────────────────

void activateLasers() {
    Serial.println("IR received - activating lasers.");

    // Turn on all lasers immediately
    turnOnAllLasers();

    // Request collision segments from C# app
    Serial.println("ReadyForSegments");

    // Flag that we're listening for a response
    waitingForSegments = true;
}

void shutdownLasers() {
    Serial.println("IR received - shutting down lasers.");

    for (int i = 0; i < relayCount; i++) {
        digitalWrite(relayPins[i], LOW);
    }

    laserState = false;
    waitingForSegments = false;

    for (int i = 0; i < relayCount; i++) {
        blinkingRelays[i] = false;
    }

    Serial.println("All lasers OFF.");
}

void turnOnAllLasers() {
    laserState = true;
    for (int i = 0; i < relayCount; i++) {
        digitalWrite(relayPins[i], HIGH);
        blinkingRelays[i] = false;
    }
    Serial.println("All lasers ON.");
}

// ─── SERIAL RESPONSE HANDLING ────────────────────────────────

void handleSerialResponse() {
    if (!waitingForSegments) return;
    if (!Serial.available()) return;

    String input = Serial.readStringUntil('\n');
    input.trim();

    Serial.print("Received from Communicator: ");
    Serial.println(input);

    if (input == "CLEAR") {
        // No collisions — lasers stay solid
        Serial.println("No collisions. Lasers remain ON.");
        waitingForSegments = false;
        return;
    }

    // Parse comma-separated segment numbers
    int startIdx = 0;
    while (startIdx < input.length()) {
        int endIdx = input.indexOf(',', startIdx);
        if (endIdx == -1) endIdx = input.length();

        int segment = input.substring(startIdx, endIdx).toInt();

        if (segment >= 1 && segment <= relayCount) {
            blinkingRelays[segment - 1] = true;
            Serial.print("Segment ");
            Serial.print(segment);
            Serial.println(" set to BLINK.");
        }

        startIdx = endIdx + 1;
    }

    waitingForSegments = false;
}

// ─── BLINK HANDLING ──────────────────────────────────────────

void handleBlinking() {
    if (!laserState) return;

    unsigned long currentMillis = millis();
    if (currentMillis - lastBlinkTime < blinkInterval) return;

    lastBlinkTime = currentMillis;

    for (int i = 0; i < relayCount; i++) {
        if (blinkingRelays[i]) {
            int currentState = digitalRead(relayPins[i]);
            digitalWrite(relayPins[i], (currentState == HIGH) ? LOW : HIGH);
        }
    }
}
